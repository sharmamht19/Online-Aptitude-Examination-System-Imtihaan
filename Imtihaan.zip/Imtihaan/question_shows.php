<?php
session_start();
    include 'api/database.php';
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/nav_custom.css">

   <style>
.my_color{
    color: #85c73d !important;
    @page {
      size: A4; /* DIN A4 standard, Europe */
      margin:0;
    }

}
   </style>
   <script type="text/javascript">

  $(document).ready(function(){
    $("#question_paper_area").hide();
$("button").click(function() {
    var test_name = $(this).val();


    if(test_name != '')
  {
     
       $("#testlist").hide();
       
        $.ajax({
    url:"api/getting_question.php",
    method:"POST",
    data:{test_name:test_name},
    dataType:"JSON",
    success:function(response)
    {

       var len = response.length;
            for(var i=0; i<len; i++){
                var question_no = response[i].question_no;
                var question = response[i].question;
                var option1 = response[i].option1;
                var option2 = response[i].option2;
                var option3 = response[i].option3;
                var option4 = response[i].option4;
                var answer = response[i].answer;

                var tr_str =  "<tr><td colspan='3'><b>" +question_no +"</b></td></tr>"+
                              "<tr><td colspan='3'>" +question +"</td></tr>"+
                              "<tr><td width='4%'></td><td width='6%'>(A) </td><td width='90%'>" +option1 +"</td></tr>"+
                              "<tr><td></td><td>(B) </td><td>" +option2 +"</td></tr>"+
                              "<tr><td></td><td>(C) </td><td>" +option3 +"</td></tr>"+
                              "<tr><td></td><td>(D) </td><td>" +option4 +"</td></tr>"+
                              "<tr><td colspan='2'><font color='green'><b>Answer :</b></font</td><td><font color='green'><b>" +answer +"</b></font></td></tr><tr><td></td></tr>";
                $("#questionsh tbody").append(tr_str);
              }
 
    }
    })
        $("#question_paper_area").show();


  }
  else
  {
   
  }
 





  
   
});
});


function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
function backbutton(){
  $("#question_paper_area").hide();
  $("#testlist").show();
  $('#questionsh tbody').empty();


}
</script>
</head>
<body >  

 
  
    <nav class="navbar navbar-custom ">
        <div class="container-fluid ">
          <div class="navbar-header">
            <div class="navbar-left"> 
                <ul>
                <a href="instruction.html">
                <img  style=" height: 70px;" src="images/signin-image.png">
            </a>
        </ul>
                    </div>
          </div>
          <ul class="nav navbar-nav">
           
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <ul class="nav navbar-nav">
               <li><a href="admin_intro.html">Home</a></li>
                <li><a href="new_test.php">Conduct a new Test</a></li>
                <li><a href="question_shows.php">Question Paper</a></li>
                <li><a href="index.php">login</a></li>
                <li><a href="#about">About</a></li>
            </ul>
          </ul>
        </div>
      </nav>
   
    <br><br>
    
<div class="container-fluid" >
          <div class="row" id="testlist">
               <table class="table table-striped" >
                 <thead>
                   <tr>
                    <th>Test Name</th>
                    <th>About Test</th>
                    <th>Number Of Question</th>
                    <th>Duration</th>
                    <th> Upload Date</th>
                    <th> view / Delete</th>
                   </tr>
                 </thead>
                 <tbody>
                   <?php
                    $sql = "SELECT * FROM `detail_of_test`";
              $result = $conn->query($sql);

              if ($result->num_rows > 0) {

   
    while($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>$row[test_name]</td>
            <td>$row[about_test]</td>
            <td>$row[number_of_que]</td>
            <td>$row[duration_of_test]</td>
            <td>$row[date]</td>
            <td><button class='btn btn-success' value='$row[test_name]'>View</button>
            </tr>";
    }
} else {
    echo "0 results";
}



                   ?>
                 </tbody>
                </table>
</div>
</div>
                 <div class="container">
                 <div class="row" id="question_paper_area">
                  <button class='btn btn-success' onclick="backbutton()">Back</button>
                  <button class='btn btn-success'onclick="printDiv('printableArea')" >Print</button>
                  <div  id="printableArea">
                   <center><img  style=" height: 100px;" src="images/signin-image.png"></center>
               <table   id="questionsh" >
                <tbody>


                  
                </tbody>
               </table>
             </div>
               
              </div>
            </div>
                

</body>
 </html>