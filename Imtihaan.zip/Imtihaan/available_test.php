<?php //session checking here
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='Login.php';
  </script>";
}

//$UserName=$_SESSION['id'];

?>
<!DOCTYPE html>
<html>
<head>
   <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<style type="text/css">

ul.a {
  list-style-type: circle;
}

.box{
    padding:10px 0px;
}

.box-part{
    background:#85c73d;
    border-radius:10px;
   padding:6px 10px;
    margin:30px 0px;
}

</style>
<script type="text/javascript">

  $(document).ready(function(){
  $("button").click(function(){
 var test_name= $(this).val();
 document.cookie = "TestName= " + test_name; 

 // $.ajax({
 //        url: 'api/create_test.php',
 //        type: 'POST',
 //        data: {
 //          test_name: test_name
 //              
 //        },
 //        cache: false,
 //        success: function(response){

 //        }
 //      });

 doNext();
 
  });
});

   function doNext(){
   // window.location='General_Instruction.php'
   window.location.replace('General_Instruction.php');
}

</script>
<body>
<div class="container-fluid" style="background-color:darkblue;width:100%;border-radius:20px;margin-left:0px;">

    <div class="row">
      
      <div class="col-md-2"><img src="images/gec_logo.png" style="height:87px;margin-left:0px;"></div>
      <div class="col-md-4"> </div>
      <div class="col-md-3"><h1 style="color:#85c73d;font-size:42px;margin-top:10px;font-family:georgia;font-weight:bold;
      text-shadow: 6px 8px 8px black,6px 8px 8px black;">I M T I H A A N</h1><font style="color:white;font-size:16px;"></font></div>
      
      <div class="col-md-3"></div>
    </div>
</div>
<form method="POST" action="General_Instruction.php">
 <div class="container">
 	<div class="box">
        <div class="row">

        	<?php
                    $sql = "SELECT * FROM `detail_of_test`";
              $result = $conn->query($sql);

              if ($result->num_rows > 0) {

   
    while($row = $result->fetch_assoc()) {
        echo "
            
<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
               
                    <div class='box-part'>
                    <div class='card'>
                     <div class='card-body'>
                        
                         <img  style=' height: 50px; position: left top; ' src='images/signin-image.png'>
                        
                      
                       <center>  <h4><b><font color='#85c73d'>$row[test_name]</font></b></h4></center>
                       

                        <ul class='a'>
					  <li>Total Questions : $row[number_of_que]</li>
					  <li>Time      : $row[duration_of_test] Sec.</li>
					  <li>Marks     : $row[number_of_que]</li>
					</ul>
                      
                 <hr>
                       ";
                        
                       
                        echo "<button class='btn  btn-success pull-right'   value='$row[test_name]'  >Click Here </button>";

                     echo"  </div>
                        </div>
                        
                     </div>
                </div> 

            ";
    }
} else {
    echo "No Tests Are available for now.......................";
}
?>
             
                
          
            
              </div>
           </div>
        </div>
</form>
</body>
</html>
