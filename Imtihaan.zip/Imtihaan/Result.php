<?php //session checking here
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
include('api/database.php');
session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='index.php';
  </script>";
}
$UserName=$_SESSION['id'];
$TestName=$_COOKIE['TestName'];
?>
<html lang="en">
<head>
<title> Results</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" 
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="favicon.ico">

<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" type="text/css" href="css/tabs.css">
<link rel="stylesheet" type="text/css" href="css/nav_custom.css">
<style>
.card img { 
width: auto; 
} 
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table 
> tbody > tr > td, .table > tfoot > tr > td { 
padding: 4px; 
} 
</style>
</head>
<body style="background-color: silver;">
<div class="container-fluid" style="background-color:darkblue;width:100%;borderradius:20px;margin-left:0px;">
<div class="row">
<div class="col-md-2"><img src="images/gec_logo.png" style="height:87px;marginleft:0px;"></div>
<div class="col-md-4"> </div>
<div class="col-md-3"><h1 style="color:white;font-size:42px;margin-top:10px;fontfamily:georgia;font-weight:bold; 
text-shadow: 6px 8px 8px black,6px 8px 8px black;">I M T I H A A N</h1><font 
style="color:white;font-size:16px;"></font></div>
<div class="col-md-3"></div>
</div>
</div>
<br>

<!-- ------------------------------------------------------------Page Started here------------------------------------------------------------- -->
<ul class="list-inline pull-left">
<li><button type="button" onclick="window.location.href='available_test.php'" class="btn btndefault prev-step" style="height: 40px;background-color:#0059b3 ;border-color: black;marginright:50px;width:90%;"><font color="white">Back &nbsp</font></button></li>
</ul>
<button type="button" class="btn btn-secondary" style="margin-right:25%;width: 50%; margin-left: 
25%; 
height: 6%; border-color: black;"><b>Result - <?php echo $TestName;?></b></button>
<div class="row" style="margin-top: 1%;"><div class="col-md-1"></div><div class="col-md-10" 
style="background-color:green;height: 7%;">



<!-------------------------------------------------Fetching and calculation Result Statistics-------------------------------------------------->

<?php
$q= "select * from student_login where User_ID='$UserName'";
$rs=mysqli_query($conn,$q);

while($row=mysqli_fetch_array($rs))
{
 $FullName=$row['fullname'];
}

$q1= "select * from detail_of_test where test_name='$TestName'";
$rs1=mysqli_query($conn,$q1);

while($row1=mysqli_fetch_array($rs1))
{
 $Total_Que=$row1['number_of_que'];
}


 $sample="_result";
 $TableName=$TestName.$sample;
 $temp="Answere";
$CountUnAnswered='0';
$CountAnswered='0';
 for($k=1;$k<=$Total_Que;$k++)
    {
       $colum=$temp.$k;
      $q3="SELECT $colum from  `$TableName` WHERE Id='$UserName' ";
      $rs3=mysqli_query($conn,$q3);
         while ($row=mysqli_fetch_array($rs3))
              {

                $Answere[$k]=$row[$colum];
              }
      }
      for($k=1;$k<=$Total_Que;$k++)
    {
      if ($Answere[$k]=='Not Answered')
       {
         $Check[$k]='1';
        $CountUnAnswered++;
      }
      else
      {
         $Check[$k]='2';
        $CountAnswered++;
      }
    }

//--------------------------------------------------Fetching Question and Answeres of the test and Comparing-------------------------------------||

  $Query_For_Test_Data="SELECT * FROM `$TestName` ORDER BY question_no ASC ";

     $rs4=mysqli_query($conn,$Query_For_Test_Data);
        
      $i=1;    
                    while ($row=mysqli_fetch_array($rs4))
              {
                $QNo[$i]=$row['question_no'];
                $questionNo[$i]=$row['question'];
                $optionA[$i]=$row['option1'];
                $optionB[$i]=$row['option2'];
                $optionC[$i]=$row['option3'];
                $optionD[$i]=$row['option4'];
                $Right_Answere[$i]=$row['answer'];
                              
                $i++;
             }
$R_Ans='0';
$W_Ans='0';

for ($j=1; $j<=$Total_Que; $j++) {

  if ($Right_Answere[$j] == $Answere[$j]) {
         $R_Ans++;
         $Check[$j]='3';
  }


}
$W_Ans=$Total_Que-($R_Ans + $CountUnAnswered);
$Score=($R_Ans*100)/$Total_Que;
?>



<div style="margin-top: 1%;"><center><b><font size="4px" color="white"s > NAME :</b><?php echo $FullName;?>
 &nbsp &nbsp &nbsp<b>User Id : </b> <?php echo $UserName;?></font></center> </div>
</div><div class="col-md-1"></div> </div>
<div class="row" style="margin-top: 1%;">
<div class="col-md-1"></div><div class="col-md-10">
<table border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered">
<tbody style="background-color: white;">
<tr>
<td align="center"><b>Total Number Of Questions : </b></td>
<td align="center"><b>No Of Questions Attempted :</b></td>
</tr>
<tr>
<td align="center"><?php echo $Total_Que;?></td>
<td align="center"><?php echo $CountAnswered;?></td>
</tr>
</tbody>
</table>
<table border="0" cellspacing="0" cellpadding="0" style="margin-top: 0.1%;" class="table table-

striped table-bordered">
<tbody style="background-color: white;">
<tr>
<td align="center"><b>Right Answeres : </b></td>
<td align="center"><b>Wrong Answeres :</b></td>
</tr>
<tr>
<td align='center' style='color: green;'><b> <?php echo $R_Ans;?> </td> 
  <td align='center' style='color: red;'><b> <?php echo $W_Ans;?></td>
</tr>
</tbody>
</table>
</div>
<div class="col-md-1"></div>
</div>
<center>
<table border="0" padding="20" style="margin-top: 0.1%;padding: 10px;border-color: black;borderradius: 10px;" >
<tbody style="background-color: white;">
<tr>
<td align="center" style="padding: 20px; padding-right: 30px;padding-left: 30px;borderradius:40px;"><b> Score </b></td>
</tr>
<tr>
<td align='center' style='color: green;size: 30px; padding:20px;padding-left: 30px;border-radius: 
10px;'><font style='font-size: 30px;'><b><?php echo $Score;?> %</font></td>
</tr>

</tbody>
</table>
</center>



<!-- -------------------------------------------------------------------------answere solution is from here ------------------------ --------------->



<div class="row" style="margin-top: 1%;"><div class="col-md-2"></div><div class="col-md-8" 
style="background-color:darkorange;height:7%;border-color:black;border-width: 12px;borderradius: 10px;">
<div style="margin-top: 1%;"><center><b><font size="4px" color="black" > Answere Analyzer</center> </div>
</div><div class="col-md-2"></div> </div>
<div class="row" style="margin-top: 1%;">
<div class="col-md-1"></div><div class="col-md-10">
<table border="2" cellspacing="0" cellpadding="0" class="table table-striped table-bordered" 
style="border-color:black;">

<?php
//-------------------------------------------Showing Questions ,Options and answeres------------------------------------------------||
for ($i=1; $i<=$Total_Que; $i++) {
echo "
<tbody style='background-color: white;'>
<tr>
<td align='left' colspan='2'><b> $QNo[$i] <b> :-  </b> $questionNo[$i] </b></td>
</tr>
<tr>
<td align='left' colspan='2'> (a) $optionA[$i]  </td>
</tr>
<tr>
<td align='left' colspan='2'>(b) $optionB[$i] </td>
</tr>
<tr>
<td align='left' colspan='2'>(c) $optionC[$i] </td>
</tr>
<tr>

<td align='left' colspan='2'>(d) $optionD[$i] </td>
</tr>
<tr> ";

if ($Check[$i]=='2') {
   echo " <td align='left'style='color: red;' ><b> Your Answere: $Answere[$i] </b></td>"; 
}
else if ($Check[$i]=='1') {
   echo " <td align='left'style='color: skyblue;' ><b> Your Answere: $Answere[$i]  </b></td>"; 
}
else {
echo "<td align='left' ><b> Your Answere: $Answere[$i] </b></td>";
}

echo "
<td align='right' style='color: green;'> <b>Right Answere is: $Right_Answere[$i] </b></td>
</tr>
<tr>
<td align='left'colspan='2' style='background-color: silver;' ></td>
</tr>
</tbody>

";
}

?>

</table>
</div>
<div class="col-md-1"></div>
</div>
<!-- last line -->
</body>
</html