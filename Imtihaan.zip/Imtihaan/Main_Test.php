<?php //session checking here
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='Login.php';
  </script>";
}

$UserName=$_SESSION['id'];
$TestName=$_COOKIE['TestName'];
$_SESSION['Total_Ans']='0';
?>
<?php // fetching questions from the database about the test --------------------------------------------------------------------

  $q1="SELECT * FROM `$TestName` ORDER BY question_no ASC ";// 

     $rs1=mysqli_query($conn,$q1);
        
      $i=1;    //$i is the total no. of question------------
                    while ($row=mysqli_fetch_array($rs1))
              {

                $questionNo[$i]=$row['question'];
                $optionA[$i]=$row['option1'];
                $optionB[$i]=$row['option2'];
                $optionC[$i]=$row['option3'];
                $optionD[$i]=$row['option4'];
                              
                $i++;
             }
   $No_Of_Que=$i-1;
?>

<?php
//---------------------------------------------already gave test but do not submit or when refresh page will get data here from data base-------
 
 $sample="_result";
 $TableName=$TestName.$sample;
 $temp="Answere";

 for($k=1;$k<=$No_Of_Que;$k++)
    {
       $colum=$temp.$k;
      $q2="SELECT $colum from  `$TableName` WHERE Id='$UserName' ";
      $rs2=mysqli_query($conn,$q2);
         while ($row=mysqli_fetch_array($rs2))
              {

                $Answere[$k]=$row[$colum];
              }
      }
      for($k=1;$k<=$No_Of_Que;$k++)
    {
      if ( $Answere[$k]=='Not Answered')
       {
      
      }
      else
      {
        $_SESSION['Total_Ans']++;
      }
    }

     $q3="SELECT Duration from  `$TableName` WHERE Id='$UserName' ";
      $rs3=mysqli_query($conn,$q3);
         while ($row=mysqli_fetch_array($rs3))
              {

              $Duration=$row['Duration'];
              }
     


      ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="js/tabs.js"></script>
    <link rel="stylesheet" type="text/css" href="css/tabs.css">
    <link rel="stylesheet" type="text/css" href="css/nav_custom.css">

   

    <script>
       //function for timer counting---------------------------------------------------Timer Updation-----------------------------------------||
  var count =<?php echo $Duration; ?>;
  var Rtime=count;
var interval = setInterval(function(){
  var hr=Math.floor(count/(60*60));
  var min=Math.floor((count%(60*60))/60);
  var sec=Math.floor((count%(60*60))%60);
  document.getElementById('hr').innerHTML=hr;
  document.getElementById('min').innerHTML=min;
  document.getElementById('sec').innerHTML=sec;
  count--;
  Rtime=count;
  if (count === 0){
    clearInterval(interval);
   alertTM('TIME OUT ::');
  
  }
}, 1000);
//---------------------------------ajax function to update time in database----------------------------------------------------------------------||
var interval2=setInterval(function(){

       $.ajax({
   
                type:'POST',
                url:'api/Time_update.php',
                data:{
          Duration:Rtime,
                      },
         success:function(html)
                {
                    $('#1010').html(html);
                     
                }
                 });
    
}, 20000); 
 if (Rtime === 0){
    clearInterval(interval2);
  }
 
  //function for befor submitting alert surity and styles--------------------------------------||
 function complete(){
    alertMX('ARE YOU SURE YOU WANT TO SUBMIT');
  }

$("<style type='text/css'>#boxMX{display:none;background: #333;padding: 10px;border: 2px solid #ddd;float: left;font-size: 1.2em;position: fixed;top: 50%; left: 50%;z-index: 99999;box-shadow: 0px 0px 20px #999; -moz-box-shadow: 0px 0px 20px #999; -webkit-box-shadow: 0px 0px 20px #999; border-radius:6px 6px 6px 6px; -moz-border-radius: 6px; -webkit-border-radius: 6px; font:13px Arial, Helvetica, sans-serif; padding:6px 6px 4px;width:300px; color: white;}</style>").appendTo("head");

function alertMX(t){
$( "body" ).append( $( "<div id='boxMX'><P></P><p class='msgMX'></p><br> <button style='background-color:white ;margin-left:120px;margin-top:40px;height:30px;width:70px;border:green;color:black;'> <b>cencel</b></button><button onclick='change()' style='background-color:green ;margin-left:40px;height:30px;width:50px;border:green;' ><b>ok</b></button></div>" ) );
$('.msgMX').text(t); var popMargTop = ($('#boxMX').height() + 24) / 2, popMargLeft = ($('#boxMX').width() + 24) / 2; 
$('#boxMX').css({ 'margin-top' : -popMargTop,'margin-left' : -popMargLeft, 'height':150,'width':300,}).fadeIn(200);
$("#boxMX").click(function() { $(this).remove(); }); 
 };

 function alertTM(t){
$( "body" ).append( $( "<div id='boxMX'><P></P><p class='msgMX'></p><br><button onclick='change()' style='background-color:green ;margin-left:110px;height:40px;width:60px;border:green;' ><b>ok</b></button></div>" ) );
$('.msgMX').text(t); var popMargTop = ($('#boxMX').height() + 24) / 2, popMargLeft = ($('#boxMX').width() + 24) / 2; 
$('#boxMX').css({ 'margin-top' : -popMargTop,'margin-left' : -popMargLeft, 'height':150,'width':300,}).fadeIn(200);
$("#boxMX").click(function() { $(this).remove(); }); 
 };


function change(){
 window.location="complete_Test.php";
}

  //function to change color of ans bos into green when answere is given and to fetch the value of radio--------------------------------------||
 
  //function to change and upload answere temporary in data base--------------------------------------||
   
 <?php 
for ($i=1; $i<=$No_Of_Que; $i++) { 
                       echo "
                       $(document).ready(function(){
      $('#$i').click(function(){
  var radioButtons=document.getElementsByName('option$i');
               
  for (var x = 0; x < radioButtons.length; x++)
   {
      if (radioButtons[x].checked) 
      {
       
       var ea = document.getElementById('m$i');
        ea.style.backgroundColor = 'green';
        ea.style.color='black';         
      
    }
   }
 });

});
  
$(document).ready(function(){
  $('#$i').click(function(){
var radioButtons=document.getElementsByName('option$i');
               
  for (var x = 0; x < radioButtons.length; x++)
   {
      if (radioButtons[x].checked) 
      {
       var Ans=radioButtons[x].value;
        var questionNo= $(this).val();

        if(questionNo){
            $.ajax({
                type:'POST',
                url:'api/answere_Upload.php',
                data:{
          QUE: questionNo,
          ANS: Ans,
                      },
         success:function(html)
                {
                    $('#1001').html(html);
                     
                }
                 }); 
                   }
        else{
            $('#1001').html('0');
             }

        }
      }
    });
});
";
}
?>
   //----------------------------------------------------------------------------------------------------------------------||
      

  //function to unmark and not  upload answere temporary in data base--------------------------------------||
   
 <?php 
  echo $c=$No_Of_Que+2000;
  $j=1;
for ($i=2001; $i<=2005; $i++) {

                       echo "
                       $(document).ready(function(){
  $('#$i').click(function(){
               
  
        var questionNo= $(this).val();
  var radioButtons=document.getElementsByName('option$j');
               
  for (var x = 0; x < radioButtons.length; x++)
   {
      if (radioButtons[x].checked) 
      {
            
        if(questionNo){
            $.ajax({
                type:'POST',
                url:'api/answere_Upload_not.php',
                data:{
          QUE: questionNo,
          
                      },
         success:function(html)
                {
                    $('#1001').html(html);
                     
                }
                 }); 
                   }
        else{
            $('#1001').html('0');
             }

      
    }
   }
      
       
    });
});


                       $(document).ready(function(){
      $('#$i').click(function(){
   var radioButtons=document.getElementsByName('option$j');
               
  for (var x = 0; x < radioButtons.length; x++)
   {
      if (radioButtons[x].checked) 
      {
         radioButtons[x].checked=false;
        
       var ea = document.getElementById('m$j');
        ea.style.backgroundColor = 'white';
        ea.style.color='blue';  
      
    }
   }
              
      
   
 });

});
  

";
$j++;
}
?>
   //----------------------------------------------------------------------------------------------------------------------||
         </script>
<style>
body {
    background : #f8f8f8;
   }
   label{
       color: ;
   }
   </style>
   <style type="text/css">
     .wizard {
    margin: 2px auto;
    background: #fff;
}

    .wizard .nav-tabs {
        position: relative;
        margin-bottom: 0;
        border-bottom-color: #e0e0e0;
    }

    .wizard > div.wizard-inner {
        position: relative;
    }

.wizard .nav-tabs > li.active > a, .wizard .nav-tabs > li.active > a:hover, .wizard .nav-tabs > li.active > a:focus {
    color: #85c73d !important;
    cursor: default;
    border: 0;
    border-bottom-color: transparent;
}

span.round-tab {
 
    width:35px;
    height: 35px;
    line-height: 35px;
    display: inline-block;
    border-radius: 10px;
    background: #fff;
    border: 3px solid #e0e0e0;
    z-index: 2;
    position: absolute;
    left: 0;
    text-align: center;
    font-size: 15px;
}
span.round-tab i{
    color:#555555;
}
.wizard li.active span.round-tab {
    background: #fff;
    border: 2px solid #5bc0de;
    
}
.wizard li.active span.round-tab i{
    color: #5bc0de;
}

span.round-tab:hover {
    color: #333;
    border: 2px solid #333;
}

.wizard .nav-tabs > li {
    width: 25%;
}

.wizard li:after {
    content: " ";
    position: absolute;
    left: 36%;
    opacity: 0;
    margin: 0 auto;
    bottom: 0px;
    border: 2px solid transparent;
    border-bottom-color: #5bc0de;
    transition: 0.1s ease-in-out;
}

.wizard li.active:after {
    content: " ";
    position: absolute;
    left: 46%;
    opacity: 1;
    margin: 0 auto;
    bottom: 0px;
    border: 10px solid transparent;
    border-bottom-color: #5bc0de;color: #85c73d !important;
 margin-top:15px;
}

.wizard .nav-tabs > li a {
    width:25px;
    height: 25px;
    margin: 6px auto;
    border-radius: 100%;
    padding: 0;
 margin-top:15px;
}

    .wizard .nav-tabs > li a:hover {
        background: transparent;
    }

.wizard .tab-pane {
    position: relative;
    padding-top: 50px;
}

.wizard h3 {
    margin-top: 5px;
}

@media( max-width : 585px ) {

    .wizard {
        width: 90%;
        height: auto !important;
    }

    span.round-tab {
       
        font-size: 5px;
        width: 35px;
        height: 35px;
        line-height: 35px;
    }

    .wizard .nav-tabs > li a {
        
        width: 35px;
        height: 35px;
        line-height: 35px;
    }

    .wizard li.active:after {
        content: " ";
        position: absolute;
        left: 35%;
    }
}
   </style>
<script type="text/javascript">
  
</script>



</head>

   <body style="background-color:#e2e2e2;">
   
     <div class="container-fluid" style="background-color:darkblue;width:100%;border-radius:20px;margin-left:0px;">
      <div class="row">
      <div class="col-md-2"><img src="images/gec_logo.png" style="height:87px;margin-left:0px;"></div>
     <div class="col-md-4"> </div>
       <div class="col-md-3"><h1 style="color:white;font-size:42px;margin-top:10px;font-family:georgia;font-weight:bold;
      text-shadow: 6px 8px 8px black,6px 8px 8px black;">I M T I H A A N</h1><font style="color:white;font-size:16px;"> </font></div>
       <div class="col-md-3"></div>
     </div>
        </div>
       <br><br>
<div class="container-fluid" style="background-color: white;height:500px ;width:95% ;margin-left:30px;margin-right:20px ;margin-top:20px; border-radius: 10px;">
 <form name="form" method="GET" >
  <div class="row">
        <div class="col-md-9" style="height: 100%;">
  <div style=" width:100%;height: 480px; overflow: auto;" >
    <!--Question Start hear-->
    <div class="container-fluid" >
   
        <form role="form">
            <div class="tab-content">
             
                <div class="tab-pane active" role="tabpanel" id="Question_1"  >
                      
                        <div class='form-group'>
                          <label for='Question1'><br> Question No 1 :-</label>
                        <?php echo $questionNo['1'] ;?>
                         
                        </div>
                        <div class='form-group'><input type="radio" id="option1" name="option1" value="A" style="height: 15px;width: 15px;">
                            <label for='Option1'> <?php echo $optionA['1'] ;?></label>
                           </div>
                      
                        <div class='form-group'><input type="radio" id="option1" name="option1" value="B" style="height: 15px;width: 15px;">
                            <label for='Option2'> <?php echo $optionB['1'] ;?></label>
                            </div>
                          <div class='form-group'><input type="radio" id="option1" name="option1" value="C" style="height: 15px;width: 15px;">
                            <label for='Option3'> <?php echo $optionC['1'] ;?></label>
                            </div>
                          <div class='form-group'><input type="radio" id="option1" name="option1" value="D" style="height: 15px;width: 15px;">
                            <label for='Option4'> <?php echo $optionD['1'] ;?></label>
                            </div>
                  
                        <button type='button' class='btn btn-default' id="2001" value="1"   style='height: 40px;background-color:brown ;border-color: black;margin-left:60px;'><font color='white'> &#9746; UNMARK &nbsp</font></button>
                      <ul class="list-inline pull-right">
                         <li><button type='button' class='btn btn-default next-step' style='height: 40px;background-color:#9833;border-color: black;width:70px;margin-right:20px;'>SKIP</button></li>
                        <li><button type="button" class="btn btn-primary  next-step" id="1" value="1" style="height: 40px; background-color:#0059b3 ;">&nbsp SAVE & NEXT > &nbsp</button></li>
                    </ul>
                </div>
         <?php
             $t=2002;
              for ($i=2; $i<=$No_Of_Que; $i++) {

              echo "
                   <div class='tab-pane' role='tabpanel' id='Question_$i'>
                     <div class='form-group'>
                        <label for='Question$i'><br> Question No $i :-</label>
                            $questionNo[$i] </div>
                              <div class='form-group'>
                                 <input type='radio' id='option$i' name='option$i' value='A' style='height: 15px;width: 15px;'>
                                    <label for='Option1'>  $optionA[$i] </label>
                              </div>
                              <div class='form-group'>
                                 <input type='radio' id='option$i' name='option$i' value='B' style='height: 15px;width: 15px;'>
                                    <label for='Option2'>$optionB[$i] </label>
                              </div>
                              <div class='form-group'>
                                   <input type='radio' id='option$i' name='option$i' value='C' style='height: 15px;width: 15px;'>
                                    <label for='Option3'> $optionC[$i] </label>
                              </div>
                              <div class='form-group'>
                                 <input type='radio' id='option$i' name='option$i' value='D' style='height: 15px;width: 15px;'>
                                   <label for='Option4'> $optionD[$i] </label>
                              </div>
                   <ul class='list-inline pull-left'>
                        <li>
                        <button type='button' class='btn btn-default  prev-step'  style='height: 40px;background-color:#0059b3 ;border-color: black;'><font color='white'>  < PREVIOUS &nbsp</font></button></li>
                       
                    </ul>

                        <button type='button' class='btn btn-default' id='$t' value='$i'  style='height: 40px;background-color:brown ;border-color: black;margin-left:20px;'><font color='white'> UNMARK &nbsp</font></button>
                      <ul class='list-inline pull-right'>
                        <li><button type='button' class='btn btn-default next-step' style='height: 40px;background-color:#9833;border-color: black;width:70px;margin-right:20px;'>SKIP</button></li>
                        <li><button type='button' class='btn btn-primary  next-step' id='$i' value='$i' style='height: 40px; background-color:#0059b3 ;'>&nbsp 
                        SAVE & NEXT > &nbsp</button></li>
                    </ul> 
        
                 </div>
                      ";
                      $t++;
         
    }
          ?>
               

              
                <div class="clearfix"></div>
            </div>
        </form>
      </div>




</div>
</div>
      <div class="col-md-3" style="background-color:;height:500px;z-index: 1;">
    <br> <center><b> Answered questions :</b><div id=1001 style="background-color:green;width: 20px;color: white;border-radius:30px; "><?php echo 
    $_SESSION['Total_Ans']; ?></div> </center>
        <center><font style="color:darkblue;"><b>Time Left:</b></font>
          <text id="hr" style="color:green;font-weight: bold;">starting..</text> : <text id="min" style="color:green;font-weight: bold;font-size: 17px;">..</text> : <text id="sec" style="color:red;font-weight: bold;font-size: 19px;">..</text>
        
</center><br> 
       <div style="z-index: 2; background-color:darkblue;height:40px;width:70%;margin-left: 40px;margin-right: 10px;position: absolute;border-radius: 8px;"> <font  color="white"><h4><center>Question palette</center></h4></font></div>
  <br><section><br>
    <div style=" width:100%;height: 300px; overflow: auto;" >
        <div class="wizard" style="background-color: #e2e2e2;height:300px;width:100%;">
            <div class="wizard-inner">
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active">
                        <a href="#Question_1" data-toggle="tab" aria-controls="Question 1" role="tab" title="Question 1">
                            <span class="round-tab" id="m1" style=" box-shadow: 2px 3px 3px black ,2px 3px 3px #e2e2e2;">
                                <p>1</p>
                            </span>
                        </a>
                    </li>
        <?php

             for ($i=2; $i <=$No_Of_Que; $i++) 
             { 
                           echo"
                                <li role='presentation' >
                                      <a href='#Question_$i' data-toggle='tab' aria-controls='Question_$i' role='tab' title='Question $i'>
                                         <span class='round-tab' id='m$i' style=' box-shadow: 2px 3px 3px black ,2px 3px 3px #e2e2e2;'>
                                              <p>$i</p>
                                           </span>
                                      </a>
                                </li>
                             ";
            }

        ?>
                 
                    </ul>
            </div>
        </div>
        </div>

        <center>
          <input type="button" name="Submit" value="Submit" onclick="complete()" class="btn btn-info" style="background-color: green; margin-top: 5px;height: 35px; width: 50%;color: white;box-shadow: 1px 2px 3px green,2px 3px 3px green; border-color: green;">
        </center>
     
 </form>
    </section>
</div>   
 

<script type='text/javascript'>

<?php
//---------------------------------------------already gave test but do not submit or when refresh page will get data here from data base-------
 
 $sample="_result";
 $TableName=$TestName.$sample;
 $temp="Answere";

 for($k=1;$k<=$No_Of_Que;$k++)
    {
       $colum=$temp.$k;
      $q2="SELECT $colum from  `$TableName` WHERE Id='$UserName' ";
      $rs2=mysqli_query($conn,$q2);
         while ($row=mysqli_fetch_array($rs2))
              {

                $Answere[$k]=$row[$colum];
              }
      }
     
      ?>
   <?php
    for($k=1;$k<=$No_Of_Que;$k++){


echo "
  var radioButtons=document.getElementsByName('option$k');
             
  for (var x = 0; x < radioButtons.length; x++)
   {
        
      if (radioButtons[x].value=='$Answere[$k]') 
      {
       radioButtons[x].checked=true;
       var ea = document.getElementById('m$k');
        ea.style.backgroundColor = 'green';
        ea.style.color='black';
       }
      }
       ";
     }
     //--------------------------------------------------------------------------------------------------------------------------------------------
 ?>
</script>


       
</body>
</html>