<?php
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='Login.php';
  </script>";
}

$UserName=$_SESSION['id'];
?>
<html lang="en">
<head>
   <link rel="icon" type="image/x-icon" href="favicon.ico">
  <title> test is continue</title>
   <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/tabs.css">
    <link rel="stylesheet" type="text/css" href="css/nav_custom.css">

 </head>
 <body style="background-color: silver;">

	<div class="container-fluid" style="background-color:darkblue;width:100%;border-radius:20px;margin-left:0px;">

		<div class="row">
			
			<div class="col-md-2"><img src="images/gec_logo.png" style="height:87px;margin-left:0px;"></div>
			<div class="col-md-4"> </div>
			<div class="col-md-3"><h1 style="color:white;font-size:42px;margin-top:10px;font-family:georgia;font-weight:bold;
			text-shadow: 6px 8px 8px black,6px 8px 8px black;">I M T I H A A N</h1><font style="color:white;font-size:16px;"></font></div>
			
			<div class="col-md-3"></div>
		</div>
</div>
   <button type="button" onclick="window.location.href='General_Instruction.php'" class="btn btn-secondary" style="margin-left:2%;width: 48%;height: 6%;"> General Instructions</button>
      <button type="button" onclick="window.location.href='Important_Instruction.php'" class="btn btn-info" style="margin-right:2%;width: 47%;background-color:blue;
      height: 6%;"> Important Instructions</button>

      <br>
      <center><u><h3><font color="darkblue">Read the following instructions care fully</font></h3></u></center>
                                <div class="row" style="margin-top: 1%;">
                                  <div class="col-md-1"></div><div class="col-md-10">
                                    <table border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered"> 
                                        <tbody style="background-color: white;">
                                            <tr>
                                                
                                                <td><b>1.</b> The question peper consists of multiple choice questions (MCQ) and numerical answere type. </td>
                                            </tr>
                                            <tr>
                                                 <td><b>2.</b> Multiple type choice questions will have four choices against A,B,C and D out of which only <b>One</b> is correct answere .</td>
                                            </tr>
                                            <tr>
                                                <td><b>3.</b> The candidate has to choose the correct answere by clicking  on radio button ( <input name="" type="radio" value="" checked="checked"> ) placed before the choice.</td>
                                            </tr>
                                            <tr>
                                                <td><b>4.</b> For numerical answere type questions ,there will not be any choice. <b>For these questions ,the answere should be entered</b> with the help of mouse and by using virtual keypad that apears on the monitors. </td>
                                            </tr>
                                            <tr>
                                                <td><b>5.</b> All the questions that are not attempted will result in zero marks.  </td>
                                            </tr>
                                           
                                            <tr>
                                                <td><b>6.</b>There is no negative marking for wrong answere. </td>
                                            </tr>
                                           
                                        </tbody>
                                    </table>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            

                    <ul class="list-inline pull-left">
                        <li><button type="button"   onclick="window.location.href='General_Instruction.php'" class="btn btn-default  prev-step"  style="height: 40px;background-color:#0059b3 ;border-color: black;"><font color="white">< Previous &nbsp</font></button></li>
                    </ul>


                    <ul class="list-inline pull-right">
                        <li><button type="button" class="btn btn-primary"  onclick="window.location.href='Start_Test.php'" next-step" style="height: 50px;width: 100px; background-color:green ;">&nbsp<b> start :-</b> &nbsp</button></li>
                    </ul> 




    

 </body>
 </html>