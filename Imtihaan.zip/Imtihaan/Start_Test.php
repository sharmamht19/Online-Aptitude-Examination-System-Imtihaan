<?php
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='Login.php';
  </script>";
}

 $UserName=$_SESSION['id'];
 $TestName=$_COOKIE['TestName'];
 $sample="_result";
 $TableName=$TestName.$sample;
 $_SESSION['Total_Ans']='0';
  $sql_result_base="INSERT INTO `$TableName` (`Id`, `Test_Name`) VALUES ('$UserName', '$TestName')";
  if (mysqli_query($conn, $sql_result_base))
   {
     //new row uploaded secton

   echo"<script>
    window.location='Main_Test.php';
  </script>"; 
   } 
  else 
  {
    //not uploaded section

echo"<script>
    alert('Please Check your connection ,you need strong network for test');
    
  </script>"; 
  }
  mysqli_close($conn); 


?>
