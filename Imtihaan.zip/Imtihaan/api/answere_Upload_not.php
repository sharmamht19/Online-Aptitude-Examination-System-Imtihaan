<?php
//Include database configuration file
include('connection.php');

if(isset($_POST["QUE"]) && !empty($_POST["QUE"])){
   // Get all state data
   
session_start();

 $UserName=$_SESSION['id'];
 $TestName=$_COOKIE['TestName'];
 $sample="_result";
 $TableName=$TestName.$sample;
 
  $QUE=$_POST['QUE'];
  $temp="Answere";
   $colum=$temp.$QUE;
 $_SESSION['Total_Ans']--;
 $Total_Answere=$_SESSION['Total_Ans'];
$sql_ans="UPDATE `$TableName` SET $colum='Not Answered' WHERE Id='$UserName' ";

$rt=mysqli_query($conn,$sql_ans);
  echo $Total_Answere;
  mysqli_close($conn);

}

?>