<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="imtihaan";
	$conn = mysqli_connect($servername, $username, $password,$db);
?>