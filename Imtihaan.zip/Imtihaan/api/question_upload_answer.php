<?php
session_start();
 $test_name=$_SESSION['test_name'];
    include 'database.php';
	$question=$_POST['question'];
	$question_no=$_POST['question_no'];
	$option1=$_POST['option1'];
	$option2=$_POST['option2'];
	$option3=$_POST['option3'];
	$option4=$_POST['option4'];
	$answer=$_POST['answer'];

$sql_que_opt_ans="INSERT INTO `$test_name` ( `question_no`,`question`, `option1`, `option2`,`option3`, `option4`,`answer`) VALUES
 ('$question_no','$question', '$option1', '$option2','$option3', '$option4','$answer')";


	if (mysqli_query($conn, $sql_que_opt_ans)) {
		echo json_encode(array("responce"=>"success"));
	} 
	else {
		echo json_encode(array("responce"=>"failed"));
		//echo "no";
	}
	mysqli_close($conn);
?>
