<?php
session_start();
    include 'database.php';
	$test_name=$_POST['test_name'];
	$test_name_ans=$test_name."_result";
	$number_of_que=$_POST['number_of_que'];
	$about_test=$_POST['about_test'];
	$duration_of_test=$_POST['duration_of_test'];
	$duration_of_test=$duration_of_test*60;
	$date=date("d/m/y");
	$_SESSION["number_of_que"] =$number_of_que;
	$_SESSION["test_name"]=$test_name;
	$_SESSION["duration_of_test"]=$duration_of_test;
    $sql_detail_of_test=	"INSERT INTO `detail_of_test` (`s_no`, `test_name`, `about_test`, `number_of_que`,`duration_of_test`, `date`) VALUES (NULL, '$test_name', '$about_test', '$number_of_que','$duration_of_test', '$date')";



    $sql_create_table = "CREATE TABLE `$test_name` (question_no VARCHAR(15) PRIMARY KEY ,question VARCHAR(500) ,option1 VARCHAR(30) NOT NULL,option2 VARCHAR(30) NOT NULL,option3 VARCHAR(30) NOT NULL,option4 VARCHAR(30) NOT NULL,answer VARCHAR(30) NOT NULL )";
    $sql_create_table_ans="CREATE TABLE `$test_name_ans` ( Id VARCHAR(50) PRIMARY KEY, Test_Name VARCHAR(50), Duration INTEGER(50) DEFAULT '$duration_of_test' )";


	if (mysqli_query($conn, $sql_detail_of_test)&&mysqli_query($conn, $sql_create_table)&&mysqli_query($conn, $sql_create_table_ans)) {

		for ($i=1; $i <=$number_of_que; $i++) { 
			$colname="Answere".$i;
				$sql_create_table_ans_col="ALTER TABLE `$test_name_ans` ADD `$colname` VARCHAR(15) DEFAULT 'Not Answered'" ;
				mysqli_query($conn, $sql_create_table_ans_col);
			
		}
		$sql_create_table_ans_status="ALTER TABLE `$test_name_ans` ADD Status VARCHAR(20)" ;
		mysqli_query($conn, $sql_create_table_ans_status);
			
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>
