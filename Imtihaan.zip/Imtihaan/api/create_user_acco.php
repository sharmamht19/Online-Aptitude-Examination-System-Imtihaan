<?php
session_start();
    include 'database.php';
	$fullname=$_POST['fullname'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$rollno=$_POST['rollno'];
	
    $q="INSERT INTO `student_login` (`User_Id`,  `Password`, `fullname`,`email`,`rollno`) VALUES 
    ('$email', '$password','$fullname', '$email','$rollno')";
   

    if(mysqli_query($conn,$q)){
     echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>

