<?php
//Include database configuration file
include('api/connection.php');

if(isset($_POST["Duration"]) && !empty($_POST["Duration"])){
   // Get all state data
   
session_start();

 $UserName=$_SESSION['id'];
 $TestName=$_COOKIE['TestName'];
 $sample="_result";
 $TableName=$TestName.$sample;
 
  $Duration=$_POST['Duration'];;
   
$sql_ans="UPDATE `$TableName` SET  Duration='$Duration' WHERE Id='$UserName' ";

$rt=mysqli_query($conn,$sql_ans);
  
  mysqli_close($conn);

}

?>