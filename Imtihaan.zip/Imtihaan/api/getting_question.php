<?php
include 'database.php';

if(isset($_POST["test_name"]))
{
	$test_name=$_POST['test_name'];
	 //$test_name="nothingleft";
 
 $query = "SELECT * FROM  `$test_name` ";
 $result = mysqli_query($conn, $query);
   if ($result->num_rows > 0) {
   	 

 while($row = mysqli_fetch_array($result))
 {
 	
  $question_no= $row["question_no"];
  $question= $row["question"];
  $option1= $row["option1"];
  $option2= $row["option2"];
  $option3= $row["option3"];
  $option4= $row["option4"];
  $answer= $row["answer"];
  $data[] =array(
  "question_no" => $question_no,
  "question" => $question,
  "option1" => $option1,
  "option2" => $option2,
  "option3" => $option3,
  "option4" => $option4,
  "answer" => $answer
);

 }
}
 echo json_encode($data);
}
?>
