<?php
session_start();
 $test_name=$_SESSION['test_name'];
  $number_of_que=$_SESSION['number_of_que'];
  $duration_of_test=$_SESSION['duration_of_test'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="js/tabs.js"></script>
    <link rel="stylesheet" type="text/css" href="css/tabs.css">
    <script type="text/javascript">
      
      $(document).ready(function(){
  $("#test_cancel_back_btn").hover(function(){
           $("#backpress").show();
            $("#backpress").html('if you press Go Back , it will terminate the  Question uploading Process');
            setTimeout(function(){
               $("#backpress").hide();
            
         }, 5000);
            
  });
   
      $("#test_cancel_back_btn").click(function(){
          window.location.href = "new_test.php";
  });
});


<?php 
for ($i=1; $i<=$number_of_que; $i++) { 
                       echo "
$(document).ready(function(){
   

    $('#save_question$i').click(function(){


      var question = $.trim($('#question$i').val());
      var option1 = $('#option1_$i').val();
      var option2 = $('#option2_$i').val();
      var option3 = $('#option3_$i').val();
      var option4 = $('#option4_$i').val();
      var question_no = 'Question No $i';

      var answer_option = $('input[name=answer_option$i]:checked').val();
      
      

      if (question!='' && option1!='' && option2!='' && option3!='' && option4!='' && answer_option!='') {
        alert('this is outer working');

         $.ajax({
        url: 'api/question_upload_answer.php',
        type: 'POST',
        data: {
          question: question,
          option1: option1,
          option2: option2,
          option3: option3,
          option4: option4,
          answer: answer_option, 
          question_no:question_no
        },
        cache: false,
        success: function(dataResponse){
           $('#content_of_form$i').hide();
         $('#success_upload_que_alert$i').show();
            $('#success_upload_que_alert$i').html('Question No $i Upload SuccessFully'); 
            $('#save_question$i').hide(); 
            $('#traverse_next_btn$i').show();
          var response = dataResponse
          if(response.statusCode==200){
          }
          else if(response.statusCode==201){
             alert('Error occured !');
          }
          
        }
      });


      }   
     });
     
});
";}?>


    </script>
    
  

<style>
body {
    background : #f8f8f8;
   }
   label{
       color: #85c73d;
   }
   div.question_icons
   {
  width: 90%;
  height: 600px;
  overflow: auto;
}
   </style>


</head>
<body>

   
<div style="margin: auto;width: 60% ; ">
  <div class="alert alert-danger alert-dismissible" id="backpress" style="display:none;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
  </div>
</div>
        <div class="container">
          <div class="row">
            <div class="col-sm-2">
              <img  style=" height: 50%; width: 50%" src="images/signin-image.png">
            </div>
            <div class="col-sm-8">
               <table class="table">
                 <thead>
                  <tr  >
                    <th>Test Name</th>
                   <th>Number of Question</th>
                   <th> Duration</th>
                 </tr>
              </thead>
             <tbody>
     
      <tr class="success">
       <?php echo "   <td>$test_name</td>
        <td>$number_of_que</td>
        <td>$duration_of_test</td> ";?>
      </tr>
    </tbody>
  </table>

            </div>
             <div class="col-sm-1">
              <br><br>
              <input type="button" class="btn btn-danger" name="test_cancel_back_btn" id="test_cancel_back_btn" value="Go Back">
             </div>
          </div>
         
        </div>



        <div class="container-fulid">
          <div class="row">
            <div class="col-sm-1">
              
            </div>
            <div class="col-sm-8">
              <div class="question_icons"> 
                <form role="form">
                   <div class="tab-content">
                      <div class="tab-pane active" role="tabpanel" id="upload_question1">

                      <div style="margin: auto;width: 60%; margin-top: auto;">   
                        <div class="alert alert-success alert-dismissible" id="success_upload_que_alert1" style="display:none;">
                          
                          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        </div>
                      </div>
                      <div id="content_of_form1">
                         <form method='POST' id='q_form1'>
                          <div class='form-group'>
                          <label for='question1'> Question No 1</label>
                          <textarea type='text'  rows='8'class='form-control bigbox' id='question1' placeholder='Enter Question 1' name='question1' required ></textarea> 
                        </div>

                        <div class='form-group'>
                            <label for='option1'>Option 1 :</label>
                            <input type='text'  class='form-control' id='option1_1' placeholder='Enter  fist Option' name='option1' required >
                          </div>

                          <div class='form-group'>
                            <label for='option2'>Option 2 :</label>
                            <input type='text'  class='form-control' id='option2_1' placeholder='Enter  Second Option' name='option2' required >
                          </div>
                          <div class='form-group'>
                            <label for='option3'>Option 3 :</label>
                            <input type='text'  class='form-control' id='option3_1' placeholder='Enter  third Option' name='option3' required >
                          </div>
                          <div class='form-group'>
                            <label for='option4'>Option 4 :</label>
                            <input type='text'  class='form-control' id='option4_1' placeholder='Enter  fourth  Option' name='option4' required>
                          </div>
                          <label> Choose Correct Answer :</label>
                          <br>
                           <input type='radio'  name='answer_option1'; value='A'>
                            <label for='answer_option'>Option 1</label>&nbsp &nbsp
                           <input type='radio'  name='answer_option1' value='B'>
                            <label for='answer_option'>Option 2</label>&nbsp &nbsp
                           <input type='radio'  name='answer_option1' value='C'>
                           <label for='answer_option'>Option 3</label>&nbsp &nbsp
                           <input type='radio' name='answer_option1' value='D'>
                           <label for='answer_option'>Option 4</label>

            </form></div>

                        <ul class="list-inline pull-right">
                        <li><button type="button" class="btn btn-primary next-step"  id="save_question1">Save and continue</button></li>
                        <li><button type="button" class="btn btn-primary next-step"  id="traverse_next_btn1" style="display:none;">Next Question</button></li>
                        </ul>
                      </div>

                      <?php for ($i=2; $i<=$number_of_que ; $i++) { 
                       echo "
                      <div class='tab-pane' role='tabpanel' id='upload_question$i'>

                       <div style='margin: auto;width: 60%; margin-top: auto;'>
                        <div class='alert alert-success alert-dismissible' id='success_upload_que_alert$i' style='display:none;'>
                          <a href='#'' class='close' data-dismiss='alert' aria-label='close'>×</a>
                        </div>
                      </div>
                      <div id='content_of_form$i'>

                       <form method='POST' id='q_form$i'>
                          <div class='form-group'>
                          <label for='question$i'> Question No $i</label>
                          <textarea type='text'  rows='8'class='form-control bigbox' id='question$i' placeholder='Enter Question $i' name='question$i' required ></textarea> 
                        </div>

                        <div class='form-group'>
                            <label for='option1_$i'>Option 1 :</label>
                            <input type='text'  class='form-control' id='option1_$i' placeholder='Enter  fist Option' name='option1_$i' required >
                          </div>

                          <div class='form-group'>
                            <label for='option2_$i'>Option 2 :</label>
                            <input type='text'  class='form-control' id='option2_$i' placeholder='Enter  Second Option' name='option2_$i' required >
                          </div>
                          <div class='form-group'>
                            <label for='option3_$i'>Option 3 :</label>
                            <input type='text'  class='form-control' id='option3_$i' placeholder='Enter  third Option' name='option$i' required >
                          </div>
                          <div class='form-group'>
                            <label for='option4_$i'>Option 4 :</label>
                            <input type='text'  class='form-control' id='option4_$i' placeholder='Enter  fourth  Option' name='option4_$i' required>
                          </div>
                          <label> Choose Correct Answer :</label>
                          <br>
                           <input type='radio'  name='answer_option$i; value='A'>
                            <label for='answer_option'>Option 1</label>&nbsp &nbsp
                           <input type='radio'  name='answer_option$i' value='B'>
                            <label for='answer_option'>Option 2</label>&nbsp &nbsp
                           <input type='radio'  name='answer_option$i' value='C'>
                           <label for='answer_option'>Option 3</label>&nbsp &nbsp
                           <input type='radio' name='answer_option$i' value='D'>
                           <label for='answer_option'>Option 4</label>





                      </form>
                      </div>




                       <ul class='list-inline pull-right'>
                        <li><button type='button' class='btn btn-default prev-step'>Previous</button></li>
                         <li><button type='button' class='btn btn-primary next-step'  id='traverse_next_btn$i' style='display:none;'>Next Question</button></li>
                        <li><button type='button' class='btn btn-primary next-step'  id='save_question$i'>Save and continue</button></li>
                       </ul>
                     </div>";
                       # code...
                      } ?>

                    </div>
                </form>               
              </div>  
            </div>
             <div class="col-sm-3">
              <div class="question_icons">
                 <section>
       
                              <div class="wizard">
                                  <div class="wizard-inner">
                                      <ul class="nav nav-tabs" role="tablist">

                                          <li role="presentation" class="active">
                                                <a href="#upload_question1" data-toggle="tab" aria-controls="upload_question1" role="tab" title="Question 1">
                                                    <span class="round-tab">
                                                        <p>1</p>
                                                    </span>
                                                </a>
                                            </li>
                                              <?php 
                                              for ($i=2; $i <=$number_of_que ; $i++) { 
                                               echo"
                                               <li role='presentation' >
                                                  <a href='#upload_question$i' data-toggle='tab' aria-controls='upload_question$i' role='tab' title='Question $i'>
                                                      <span class='round-tab'>
                                                          <p>$i</p>
                                                      </span>
                                                  </a>
                                              </li>
                                               ";
                                              }

                                              ?>               
                                         </ul>
                                     </div>
                                  </div>
                               </section>  
                
                
              </div>
               
             </div>
            
          </div>
        </div>
  
   </body>
</html>