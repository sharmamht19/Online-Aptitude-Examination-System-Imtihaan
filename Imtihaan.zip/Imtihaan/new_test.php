<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="js/tabs.js"></script>
    <link rel="stylesheet" type="text/css" href="css/tabs.css">
    <link rel="stylesheet" type="text/css" href="css/nav_custom.css">
    
  
<style>
body {
    background : #f8f8f8;
   }
   label{
       color: #85c73d;
   }
  

   </style>


   
   <script type="text/javascript" >

 $(document).ready(function() {
         function disablePrev() { window.history.forward() }
         window.onload = disablePrev();
         window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
      });
      </script>

   <script>
  

$(document).ready(function(){

    $("#test_detail_form_btn").click(function(){
           
      
     var test_name =$("#test_name").val();
     var number_of_que=  $("#number_of_que").val();
      var about_test=$("#about_test").val();
      var duration_of_test=$("#duration_of_test").val();
      

      if(test_name!=''&&number_of_que!='')
      {
         // $('#test_detail_form').fadeOut(1000);
         
        $.ajax({
        url: 'api/create_test.php',
        type: 'POST',
        data: {
          test_name: test_name,
          number_of_que: number_of_que,
          about_test: about_test ,
          duration_of_test:duration_of_test      
        },
        cache: false,
        success: function(response){
          var response = JSON.parse(response);
          if(response.statusCode==200){
             $('#success').show();
            $('#success').html('Test Created successfully \n please enter Question and Corrosponding Options !');
            
            setTimeout(function(){
            window.location.href = "question_upload.php";
         }, 5000);
             
                        
          }
          else if(response.statusCode==201){
             alert('Error occured !');
          }
          
        }
      });


      }
    });
});

</script>
</head>
<body>

    <nav class="navbar navbar-custom ">
        <div class="container-fluid ">
          <div class="navbar-header">
            <div class="navbar-left"> 
                <ul>
                <a href="instruction.html">
                <img  style=" height: 70px;" src="images/signin-image.png">
            </a>
        </ul>
                    </div>
          </div>
          <ul class="nav navbar-nav">
           
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <ul class="nav navbar-nav">
               <li><a href="admin_intro.html">Home</a></li>
                <li><a href="new_test.php">Conduct a new Test</a></li>
                <li><a href="question_shows.php">Question Paper</a></li>
                <li><a href="index.php">login</a></li>
                <li><a href="#about">About</a></li>
            </ul>
          </ul>
        </div>
        </nav>
    


<div style="margin: auto;width: 60%;">
  <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
  </div>


<!--         test detail start here -->                      
<div class="container " id="test_detail_form">
    <div class="row">
      <div class="col-sm-3">
        <img src="images/signin-image.png" style="width: 80%; height: 80%; margin-top: 50%">

        
      </div>
      <div class="col-sm-6">
        <h1>Fill The  Detail Of Test</h1>
        <br>
        <br>
          <form method="POST">
                        <div class='form-group'>
                            <label for='test_name :'>Test Name</label>
                            <input type='text'  class='form-control' id='test_name' placeholder='Enter  Test Name' name='test_name' required >
                          </div>
                          <br>
                           <div class='form-group'>
                            <label for='number_of_que'> Number of Question in Test :</label>
                            <input type='Number'  class='form-control' id='number_of_que' placeholder='Number of Question' name='number_of_que' required >
                          </div>

                          <div class='form-group'>
                            <label for='duration_of_test'> Duration of Test :</label>
                            <input type='Number'  class='form-control' id='duration_of_test' placeholder='Duration of Test (min)' name='duration_of_test' required >
                          </div>
                          <div class='form-group'>
                          <label for='about_test'>About Test</label>
                          <textarea type='text'  rows='5'class='form-control bigbox' id='about_test' placeholder='About Test' name='about_test'  ></textarea> 
                        </div>
                        <div class='form-group'>
                         
                          <input type="button" id="test_detail_form_btn" class="btn btn-primary" value="Next"> 
                        </div>   

         </form>   
        
      </div>
      <div class="col-sm-3">
        
      </div>
    </div>
  </div>

      
   
</body>
</html>