<?php 
include('api/database.php');
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/nav_custom.css">
    <style>
      body {
    background : #f8f8f8;
   }
    </style>
    
</head>
<body>

          
    <nav class="navbar navbar-custom ">
        <div class="container-fluid ">
          <div class="navbar-header">
            <div class="navbar-left"> 
                <ul>
                <a href="instruction.html">
                <img  style=" height: 70px;" src="images/signin-image.png">
            </a>
        </ul>
                    </div>
          </div>
          <ul class="nav navbar-nav">
           
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <ul class="nav navbar-nav">
                <li><a href="instruction.html">Home</a></li>
                <li><a href="#about">About</a></li>
            </ul>
          </ul>
        </div>
      </nav>

    <div class="main">                
        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.png" alt="sing up image"></figure>
                        <a href="create_new_account.php" class="signup-image-link">Create an account</a>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Login Student</h2>
                        <form method="POST" class="register-form" id="login-form">
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="your_name" id="your_name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="your_pass" id="your_pass" placeholder="Password"/>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="signin" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>
                        <div class="social-login">
                            <span class="social-label"> *For Adminstator only</span>
                            <a href="login_admin.php" class="signup-image-link">Sign in Admin</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
   
</body>
</html>
<?php

 if(isset($_REQUEST['your_name'])&& isset($_REQUEST['your_pass']))
 {
$username=$_REQUEST["your_name"];
$password=$_REQUEST["your_pass"];
$_SESSION['id']=$username;
 echo $username;
 echo $password;
$q= "select * from student_login where User_ID='$username' AND Password='$password'";
$rs=mysqli_query($conn,$q);

while($row=mysqli_fetch_array($rs))
{
  echo"<script>
    window.location='available_test.php';
  </script>";
}
if($row==0)
{
echo"<script>
    alert('you Entered Wrong Password');
    window.location='index.php';
  </script>";   
}


 }

  ?>