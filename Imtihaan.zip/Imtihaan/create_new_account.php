<?php 
include('api/database.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imtihaan</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/nav_custom.css">
    <style>
         body {
    background : #f8f8f8;
   }
    </style>

    <script type="text/javascript">

    function CallTheFunction(){
         // body...
         
      var name =$("#name").val();
     var email=$("#email").val();
      var rollno=$("#rollno").val();
      var pass=$("#pass").val();
       var re_pass=$("#re_pass").val();
       //alert(name);

      if(name!=''&&pass!='')
      {  
        $.ajax({
        url: 'api/create_user_acco.php',
        type: 'POST',
        data: {
          fullname: name,
          email: email,
          rollno: rollno ,
          password:pass
        },
         cache: false,
        success: function(response){
          var response = JSON.parse(response);
          if(response.statusCode==200){
            alert("Registration successfull  please LogIn!..........");
            window.location.href = "index.php";
             $('#success').show();
            $('#success').html('Registration successfull  please wait !');
            
            setTimeout(function(){
            window.location.href = "index.php";
         }, 2000);
             
                        
          }
          else if(response.statusCode==201){
             alert('Error occured !');
          }
          
        }
      });

        
    }
    else{
        alert("Registration Failed \n please enter all the fields !s");
         $('#erroring').show();
            $('#erroring').html('Registration Failed  please enter all the fields !s');

    } 
    }
   
  // console.log('log started');
   
 </script>
 
</head>
<body>


      
    <nav class="navbar navbar-custom ">
        <div class="container-fluid ">
          <div class="navbar-header">
            <div class="navbar-left"> 
                <ul>
                <a href="instruction.html">
                <img  style=" height: 70px;" src="images/signin-image.png">
            </a>
        </ul>
                    </div>
          </div>
          <ul class="nav navbar-nav">
           
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <ul class="nav navbar-nav">

                <li><a href="index.php">login</a></li>
                <li><a href="#about">About</a></li>
            </ul>
          </ul>
        </div>
      </nav>


    <div class="main">

<div style="margin: auto;width: 60%;">
  <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
  </div>
  <div class="alert alert-success alert" id="erroring" style="display:none;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
   
  </div>

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Registration</h2>
                        <form method="POST" class="register-form" id="register-form">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"/>
                            </div>

                            <div class="form-group">
                                <label for="rollno"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="number" name="rollno" id="rollno" placeholder="Your Rollno"/>
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="re_pass" id="re_pass" placeholder="Repeat your password"/>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                                <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" class="term-service">Terms of service</a></label>
                            </div>
                            <div class="form-group form-button">
                                 <input type="submit" name="signup" onclick="CallTheFunction()" id="target" class="form-submit" value="Register"/>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signin-image.png" alt="sing up image"></figure>
                        <a href="index.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

     

    </div>
   
</body>
</html>

