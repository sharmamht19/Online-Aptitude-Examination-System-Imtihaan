<?php
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='index.php';
  </script>";
}

 $UserName=$_SESSION['id'];
 $TestName=$_COOKIE['TestName'];
 $sample="_result";
 $TableName=$TestName.$sample;

$q= "SELECT * FROM `$TableName` where Id='$UserName'";
$rs=mysqli_query($conn,$q);
 
  
while($row=mysqli_fetch_array($rs))
{
 //the id is already present section
	$Status=$row['Status'];
	if($Status=="Submitted"){

		
echo"<script>
    alert('YOU HAVE ALREADY SUBMITED YOUR TEST! YOU CAN SEE YOUR RESULT HERE BY CLICK OK..');
    window.location='Result.php';
  </script>"; 
	}
	else {
		
echo"<script>
    alert('YOU HAVE NOT SUBMITED YOUR TEST BEFORE CLICK OK TO CONTINIUE..');
    window.location='Main_Test.php';
  </script>"; 

	}
}

?>

<html lang="en">
<head>
   <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title> test is continue</title>
   <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/tabs.css">
    <link rel="stylesheet" type="text/css" href="css/nav_custom.css">
<style>
  .card img {
      width: auto;
    }
    .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
    padding: 4px;
    }
</style>
 </head>
 <body style="background-color: silver;">

	<div class="container-fluid" style="background-color:darkblue;width:100%;border-radius:20px;margin-left:0px;">

		<div class="row">
			
			<div class="col-md-2"><img src="images/gec_logo.png" style="height:87px;margin-left:0px;"></div>
			<div class="col-md-4"> </div>
			<div class="col-md-3"><h1 style="color:white;font-size:42px;margin-top:10px;font-family:georgia;font-weight:bold;
			text-shadow: 6px 8px 8px black,6px 8px 8px black;">I M T I H A A N</h1><font style="color:white;font-size:16px;"></font></div>
			
			<div class="col-md-3"></div>
		</div>
</div>
                                
      <button type="button" onclick="window.location.href='General_Instruction.php'" class="btn btn-info" style="margin-left:2%;background-color:blue;width: 48%;height: 6%;"> General Instructions</button>
      <button type="button" onclick="window.location.href='Important_Instruction.php'" class="btn btn-secondary" style="margin-right:2%;width: 47%;
      height: 6%;"> Important Instructions</button>

       <div class="row" style="margin-top: 1%;"><div class="col-md-1"></div><div class="col-md-10" style="background-color: orange;height: 10%;">
                
                                      <div style="margin-top: 2%;"><center><b><font size="4px" color="white"s > NOTE:</b>  You can go to any question directly by clicking on the question numbers displayed at the right side of the screen</font></center> </div>
                                   </div><div class="col-md-1"></div> </div>
                                <div class="row" style="margin-top: 1%;">
                                  <div class="col-md-1"></div><div class="col-md-10">
                                    <table border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered"> 
                                        <tbody style="background-color: white;">
                                            <tr>
                                                <td align="center"><b>Symbol</b></td>
                                                <td><b>Description</b></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><input name="" type="radio" value=""></td>
                                                <td>Option Not Chosen.</td>
                                            </tr>
                                            <tr>
                                                <td align="center"><input name="" type="radio" value="" checked="checked"></td>
                                                <td>Option chosen as correct (By Clicking on it again you can delete your option and choose another option if desired.)</td>
                                            </tr>
                                            <tr>
                                                <td align="center"><img src="not_visited.png"></td>
                                                <td>You have not answered the question.</td>
                                            </tr>
                                            <tr>
                                                <td align="center"><img src="images/answered.png"></td>
                                                <td>You have answered the question. </td>
                                            </tr>
                                           <tr>
                                                <td align="center"><button type='button' class='btn btn-default next-step' style='height: 40px;background-color:#9833;border-color: black;width:70px;'>SKIP</button></td>
                                                <td>Clicking on this will Skip the  question and not ansered.</td>
                                            </tr>
                                            <tr>
                                                <td align="center"><button type="button" class="btn btn-primary  next-step" style="height: 40px; background-color:#0059b3 ;">&nbsp SAVE & NEXT > &nbsp</button></td>
                                                <td>Clicking on this will take you to the next question.</td>
                                            </tr>
                                            <tr>
                                                <td align="center"><button type="button" class="btn btn-default  prev-step"  style="height: 40px;background-color:#0059b3 ;border-color: black;"><font color="white">< PREVIOUS &nbsp</font></button></td>
                                                <td>Clicking on this will take you to the previous question.</td>
                                            </tr>
                                           
                                            <tr>
                                                <td align="center"> <button type='button' class='btn btn-default' id="2001" value="1"   style='height: 40px;background-color:brown ;border-color: black;'><font color='white'> &#9746; UNMARK &nbsp</font></button></td>
                                                <td>Clicking on this will un marked the answere given before  and save as not answered.</td>
                                            </tr>
                                            <tr>
                                                <td align="center"><button type="button" class="btn btn-warning"><i class="fa fa-book" aria-hidden="true"></i> <span class="hidden-xs">Question Paper</span></button></td>
                                                <td>By clicking on this button, yo can view all the question for review.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            



                     <ul class="list-inline pull-right">
                        <li><button type="button"  onclick="window.location.href='Important_Instruction.php'" class="btn btn-default  prev-step"  style="height: 40px;background-color:#0059b3 ;border-color: black;margin-right:50px;width:90%;"><font color="white">Next &nbsp</font></button></li>
                    </ul>
  
 </body>
 </html>