<?php
ob_start();
include_once('api/connection.php');
global $conn;
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if(!isset($_SESSION['id']))
{
  echo"<script>
  window.location='Login.php';
  </script>";
}
 $UserName=$_SESSION['id'];
 $TestName=$_COOKIE['TestName'];
 $sample="_result";
 $TableName=$TestName.$sample;
 
$sql_ans="UPDATE `$TableName` SET Status='Submitted' WHERE Id='$UserName' ";

$rt=mysqli_query($conn,$sql_ans);
  
  mysqli_close($conn);
?>
<html lang="en">
<head>
  <title> IMTIHAAN</title>
   <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="css/tabs.css">
    <link rel="stylesheet" type="text/css" href="css/nav_custom.css">

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <style type="text/css">
  .ui-button.ui-corner-all.ui-widget.ui-button-icon-only.ui-dialog-titlebar-close {
    display: none;
}
  </style>
 </head>
<div class="container"></div>
 <body style="background-color: silver;">
	<div class="container-fluid" style="background-color:darkblue;width:100%;border-radius:20px;margin-left:0px;">

		<div class="row">
			
			<div class="col-md-2"><img src="images/gec_logo.png" style="height:87px;margin-left:0px;"></div>
			<div class="col-md-4"> </div>
			<div class="col-md-3"><h1 style="color:white;font-size:42px;margin-top:10px;font-family:georgia;font-weight:bold;
			text-shadow: 6px 8px 8px black,6px 8px 8px black;">I M T I H A A N</h1><font style="color:white;font-size:16px;"></font></div>
			
			<div class="col-md-3"></div>
		</div>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Dialog - Animation</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


 <script>
  $( function() {
    $( "#dialog-message" ).dialog({
     autoOpen: true,
     height: 300 ,
     width : 400,
      show: {
        effect: "blind",
        duration: 500
      },
      hide: {
        effect: "explode",
        duration: 500
      },
      buttons: {
        Ok: function() {
          $( this ).dialog( "close" );
           window.location.replace('available_test.php');
        }
      }
    });
  } );
  </script>

 
<div id="dialog-message" title="successfully Submitted"   class="ui-widget" >
  <center><img src="images/Right_Icon.jpg"  style="height: 40px;width: 40px;border-radius: 20px;"></center>
  <p>
   <center>&nbsp &nbsp  You have successfully submitted your <b>Test</b></center> 
  </p>
  <br><br><br><p>
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp click <b>Ok</b> Button to go Home
  </p>
</div>
 
 


    </div>
</div>
<script type="text/javascript">
  
</script>
 </body>
 </html>
 