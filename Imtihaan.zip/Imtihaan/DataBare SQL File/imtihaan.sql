-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2022 at 01:13 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imtihaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `User_ID` varchar(20) NOT NULL,
  `Password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`User_ID`, `Password`) VALUES
('sharmamht19', 'mohit@1998');

-- --------------------------------------------------------

--
-- Table structure for table `crud`
--

CREATE TABLE `crud` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crud`
--

INSERT INTO `crud` (`id`, `name`, `email`, `phone`, `city`) VALUES
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Delhi'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Pune'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Pune'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Mumbai'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Delhi'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Delhi'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Pune'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Mumbai'),
(0, 'Om Prakash Durgam', 'prakashdurgam143@gmail.com', '9424233862', 'Delhi');

-- --------------------------------------------------------

--
-- Table structure for table `detail_of_test`
--

CREATE TABLE `detail_of_test` (
  `s_no` int(10) NOT NULL,
  `test_name` varchar(50) NOT NULL,
  `about_test` varchar(100) NOT NULL,
  `number_of_que` int(10) NOT NULL,
  `duration_of_test` int(5) NOT NULL,
  `date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_of_test`
--

INSERT INTO `detail_of_test` (`s_no`, `test_name`, `about_test`, `number_of_que`, `duration_of_test`, `date`) VALUES
(16, 'SBI', 'Enterence exam Test Conducted By mohit sharma', 5, 300, '09/07/22');

-- --------------------------------------------------------

--
-- Table structure for table `sbi`
--

CREATE TABLE `sbi` (
  `question_no` varchar(15) NOT NULL,
  `question` varchar(500) DEFAULT NULL,
  `option1` varchar(30) NOT NULL,
  `option2` varchar(30) NOT NULL,
  `option3` varchar(30) NOT NULL,
  `option4` varchar(30) NOT NULL,
  `answer` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sbi`
--

INSERT INTO `sbi` (`question_no`, `question`, `option1`, `option2`, `option3`, `option4`, `answer`) VALUES
('Question No 1', 'Choose Red', 'Blue', 'Black', 'Red', 'Yellow', 'C'),
('Question No 2', 'Choose Mind', 'Mine', 'Mind', 'Nimd', 'MInt', 'B'),
('Question No 3', 'Select Cake:', 'caker', 'Creck', 'cakh', 'cake', 'D'),
('Question No 4', 'Not Select hen :', 'Hen', 'Hen', 'Neh', 'Hen', 'C'),
('Question No 5', 'FInd the Word Test :', 'Set', 'Test', 'Toss', 'Tead', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `sbi_result`
--

CREATE TABLE `sbi_result` (
  `Id` varchar(50) NOT NULL,
  `Test_Name` varchar(50) DEFAULT NULL,
  `Duration` int(50) DEFAULT 300,
  `Answere1` varchar(15) DEFAULT 'Not Answered',
  `Answere2` varchar(15) DEFAULT 'Not Answered',
  `Answere3` varchar(15) DEFAULT 'Not Answered',
  `Answere4` varchar(15) DEFAULT 'Not Answered',
  `Answere5` varchar(15) DEFAULT 'Not Answered',
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sbi_result`
--

INSERT INTO `sbi_result` (`Id`, `Test_Name`, `Duration`, `Answere1`, `Answere2`, `Answere3`, `Answere4`, `Answere5`, `Status`) VALUES
('omprakash@gmail.com', 'SBI', 20, 'C', 'B', 'Not Answered', 'A', 'B', 'Submitted');

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `User_ID` varchar(50) NOT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `rollno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`User_ID`, `Password`, `fullname`, `email`, `rollno`) VALUES
('hitesh@gmail.com', 'hitesh@1998', 'Hitesh kodopi', 'hitesh@gmail.com', 667788990),
('omprakash@gmail.com', 'om@1998', 'om prakash', 'omprakash@gmail.com', 123456789),
('sharmamht19@gmail.com', 'lll', 'Mohit Sharma', 'sharmamht19@gmail.com', 14563215);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `detail_of_test`
--
ALTER TABLE `detail_of_test`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `sbi`
--
ALTER TABLE `sbi`
  ADD PRIMARY KEY (`question_no`);

--
-- Indexes for table `sbi_result`
--
ALTER TABLE `sbi_result`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `student_login`
--
ALTER TABLE `student_login`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `rollno` (`rollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_of_test`
--
ALTER TABLE `detail_of_test`
  MODIFY `s_no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
