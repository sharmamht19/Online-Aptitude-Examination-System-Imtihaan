main method(){
  int ch = Console.readline;
  String check;
  do{


  switch(ch)
  {
    case
    case
  }
check = Console.readline;
  } while(check=="yes")
}